package aes.tabelas;

public class MatrizMultiplicacao {

	public static Integer[][] matriz = { { 2, 3, 1, 1 }, { 1, 2, 3, 1 }, { 1, 1, 2, 3 }, { 3, 1, 1, 2 } };

}
